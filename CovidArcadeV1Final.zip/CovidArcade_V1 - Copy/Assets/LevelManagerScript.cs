﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class LevelManagerScript : MonoBehaviour
{       
    public static int CurLevel = 0;

    public TextMeshProUGUI level;

       public TextMeshProUGUI title;

          public TextMeshProUGUI desc;

    public TextMeshProUGUI CountdownText;

    public float timevar = 0;
    public int count = 3;



    void Start()
    {
        if(Blitzmode.GamesPlayed == 0){
            CurLevel = 0;
        }
        CurLevel++;
        level.text = "Level: " + CurLevel;
        Blitzmode.GamesPlayed++;


                switch(Blitzmode.gameTitles[Blitzmode.curGame]){
            case "SampleScene": 
            title.text = "The Jogger";
            desc.text = "Dodge back and forth to avoid enemies!";
            break;
            
            case "HandWash": 
            title.text = "Disinfect DogFight";
            desc.text = "Destroy all bacteria and avoid enemy fire!";
            break;

            case "tpRace": 
            title.text = "TP Race";
            desc.text = "Beat your opponent to the Toilet paper!";
            break;


            case "DontTouchFace": 
            title.text = "Dont Touch Your Face";
            desc.text = "Tap the hands before they reach the face!";
            break;

   

            case "CoughCatcher": 
            title.text = "Cough Catcher";
            desc.text = "Place the elbows on the coughers. Watch out though, they disapear!";
            break;


        }
    }

    // Update is called once per frame
    void Update()
    {
            timevar += Time.deltaTime;

        if(timevar >= 1 && count >= 1){
            timevar = 0;
            CountdownText.text = "" + count--;
        }

        if(count == 0){
            Blitzmode.playGame();

        }
    }
}
