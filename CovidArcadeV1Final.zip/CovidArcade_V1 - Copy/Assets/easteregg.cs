﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class easteregg : MonoBehaviour
{
    float x = 0;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public void OnMouseDown() {
        x++;

        if(x > 10){

            GameObject.Find("EnemyPilot (Clone)").GetComponent<EnemySpawnerScript>().dogMode = true;

        }



    }
}
