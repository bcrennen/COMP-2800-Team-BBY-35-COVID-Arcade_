﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class UserParse
{


    public string userName;
    public float userScore;
    public string localId;

    public float joggerScore;

    public float tpRaceTime;

    public float dogfightScore;

    public float coughcatcherScore;


    public float blitzmodeScore;
    public float tfScore;

}
