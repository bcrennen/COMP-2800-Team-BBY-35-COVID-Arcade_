﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Proyecto26;
using TMPro;
public class TFScoreManager : MonoBehaviour
{
    float score = 0;


    public Text highScore;
    public float blitzTime = 12f;

    public TextMeshProUGUI blitztimeText;
    public Text currentScore;
    public Text endhighScore;
    public Text endcurrentScore;

    private void Start()
        
    {
        if(!FaceScript.isBlitzMode){
        highScore.text = "Highscore: " + GlobalMenuManager.tfScore;
        blitztimeText.GetComponent<TextMeshProUGUI>().enabled = false;
        }
    }

    private void Update()
    {
        if(FaceScript.isBlitzMode){
        blitzTime -= Time.deltaTime;
        string bTime = blitzTime.ToString();
        if(blitzTime < 10){
        blitztimeText.text = "Time Left: " + bTime[0]; 
        } else {
          blitztimeText.text = "Time Left: " + bTime[0] + bTime[1]; 
        }

      }

        if(!FaceScript.isBlitzMode){
        score = (1 * HandMovementScript.score);
        currentScore.text = "Score: " + score;
        endcurrentScore.text = currentScore.text;
        

        if (score > GlobalMenuManager.tfScore)
        {
           GlobalMenuManager.tfScore = score;
            highScore.text = "Highscore: " + GlobalMenuManager.tfScore;
        }

        endhighScore.text = highScore.text;
        }
    }


        public void submitScore() {
        if(score > GlobalMenuManager.tfScore){
        GlobalMenuManager.tfScore = score;
        }
        User user = new User();
        if(GlobalMenuManager.localId == null){
            Debug.Log("no user selected");
        } else {
        RestClient.Put("https://comp-2800-bby-35.firebaseio.com/UsersId/" + GlobalMenuManager.localId + ".json", user).Catch(error =>{
            Debug.Log("error");
        });
      }



    }
}
