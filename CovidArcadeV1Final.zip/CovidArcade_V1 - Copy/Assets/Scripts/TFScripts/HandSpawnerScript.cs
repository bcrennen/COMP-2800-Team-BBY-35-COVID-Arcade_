﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandSpawnerScript : MonoBehaviour
{

    Vector3 center;
    public float spawnrate = 2f;

    public float dif;

    public float blitzTime = 12;

    public static bool isBlitzMode;
    float nextSpawn = 0.0f;
    public GameObject hand;

    void Start()
    {
        center = transform.position;

                if(isBlitzMode){
            dif = Blitzmode.diff;
        } else {
            dif = 0;
        }
        switch(dif){
            case 1:
            spawnrate = 2f;
            break;

            case 2:
            spawnrate = 1.75f;
            break;
            
            case 3:
            spawnrate = 1.5f;
            break;

            case 4:
            spawnrate = 1.25f;
            break;

            case 5:
            spawnrate = 1f;
            break;

        default:
            spawnrate = 2f;
        break;
      }
    }

    Vector3 RandomCircle(Vector3 center, float radius)
    {
        float ang = Random.value * 360;
        Vector3 pos;
        pos.x = center.x + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
        pos.y = center.y + radius * Mathf.Cos(ang * Mathf.Deg2Rad);
        pos.z = center.z;
        return pos;
    }

    // Update is called once per frame
    void Update()
    {
        if(isBlitzMode){
        blitzTime -= Time.deltaTime;
      }

      if(blitzTime <= 0){
        PlayerPrefs.SetInt("DontTouchFace", 1);
        PlayerPrefs.SetInt("BlitzScore", PlayerPrefs.GetInt("BlitzScore") + 1);
        if(!(Blitzmode.GamesPlayed % 6 == 0)){
        Blitzmode.playInterlude();
        } else {
        Blitzmode.playLevelScreen();
        }
      }



        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnrate;
            spawnrate = spawnrate * 0.95f;
            Vector3 pos = RandomCircle(center, 20.0f);
            Quaternion rot = Quaternion.FromToRotation(Vector3.forward, center - pos);
            Instantiate(hand, pos, rot);
        }

    }

}
