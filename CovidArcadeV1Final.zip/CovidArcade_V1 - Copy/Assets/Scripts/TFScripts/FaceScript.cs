﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class FaceScript : MonoBehaviour
{
    public Canvas endScreen;

    public static bool isBlitzMode;

    public Sprite doomGuy;

    public int x;
    // Start is called before the first frame update
    void Start()
    {
        HandMovementScript.score = 0;
        endScreen.GetComponent<Canvas>().enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D target)
    {
        if (target.tag == "Hand")
        {
            if(!isBlitzMode){
            endScreen.GetComponent<Canvas>().enabled = true;
            Debug.Log("GAME OVER");
            Invoke("TurnOffGameObject", 0f);
            Destroy(gameObject);
            } else {
                SceneManager.LoadScene("BlitzModeEnd");
            }
        }
    }


    public void OnMouseDown() {
        x++;

        if(x >= 20){

            gameObject.GetComponent<SpriteRenderer>().sprite = doomGuy;

        }

    }
}
