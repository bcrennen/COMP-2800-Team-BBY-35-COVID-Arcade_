﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandMovementScript : MonoBehaviour
{
    public static float score;
    public GameObject face;
    
    // Start is called before the first frame update
    void Start()
    {

    }

    void TurnOffGameObject()
    {
        gameObject.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Face")
        {
            Debug.Log("Lose health");
            Invoke("TurnOffGameObject", 0.1f);
        }
    }

    private void OnMouseDown()
    {
        score ++;
        Debug.Log("Score:" + score);
        Invoke("TurnOffGameObject", 0f);
    }
    // Update is called once per frame
    void Update()
    {
        EndTimes();
        transform.position = Vector3.MoveTowards(transform.position, face.transform.position, 0.1f);
        Vector3 dir = face.transform.position - transform.position;
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg + 270;
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
    }

    public void EndTimes()
    {
        if (GameObject.Find("Face") == null)
        {
            Destroy(gameObject);
        }
    }
}
