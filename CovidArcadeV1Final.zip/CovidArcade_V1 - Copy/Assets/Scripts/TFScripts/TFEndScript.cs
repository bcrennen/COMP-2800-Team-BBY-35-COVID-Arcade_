﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TFEndScript : MonoBehaviour
{
    private int prevSceneToLoad;

    private void Start()
    {
        prevSceneToLoad = SceneManager.GetActiveScene().buildIndex - 1;
    }
    public void PlayAgain()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void PlayGame()
    {
        SceneManager.LoadScene("DontTouchFace");
    }

    public void QuitMenu(){
        SceneManager.LoadScene("TFMenu");

    }

    public void QuitGame()
    {
        SceneManager.LoadScene("GameLibrary");
    }
}
