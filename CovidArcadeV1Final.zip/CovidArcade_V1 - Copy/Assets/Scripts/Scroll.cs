﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scroll : MonoBehaviour
{

  public float dif = 0f;
  private GameObject gM;
  private GameLogic gL;
  public float moveSpeed = 1;
  public float dis = 9.7f;
  public float offScreen;
  GameObject player;

    // Start is called before the first frame update
    void Start()
    {
      player = GameObject.Find("MC_Jogger");
     gM = GameObject.Find("GameMaster");
     gL = gM.GetComponent<GameLogic>();
    }

    // Update is called once per frame
    void Update()
    {
      if(player != null){
      dif = gL.diff;
        transform.position += new Vector3(0f, -2, 0f) * Time.deltaTime * dif * moveSpeed;
        
        if(transform.position.y <= offScreen){
          if(gameObject.tag == "Enemy"){
            Destroy(gameObject);
          } else {
          transform.position = new Vector3(transform.position.x, dis, transform.position.z);
          dis -= 0.15f;
          }
        }
    }
    }
}
