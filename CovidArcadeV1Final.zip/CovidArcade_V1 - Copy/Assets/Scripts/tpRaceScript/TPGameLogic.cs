﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;
using Proyecto26;

public class TPGameLogic : MonoBehaviour
{
    public bool RaceFinish = false;

    public Canvas endingMenu;

    public static bool PlayerLost = false;
    public Canvas endingPanel;
    public static bool isBlitzMode;
    public Canvas StartCanvas;

    public TextMeshProUGUI StartText;

    public float timescale;

    public TextMeshProUGUI highscore;

    public TextMeshProUGUI curScore;

    public float score;

    public float globalDifficulty;

    public static float eSpeed;


    public static bool gamestart = false;
    public float blitzTime;

    public TextMeshProUGUI blitztimeText;

    public GameObject place1;
    public GameObject place2;
    public GameObject place3;
    public GameObject place4;
    public GameObject place5;
    public GameObject place6;

    public GameObject sign;

    public GameObject puddle;
    
    


    void Start()
    {
        score = 0;
        PlayerLost = false;
        if(isBlitzMode){
            globalDifficulty = Blitzmode.diff;
        }

      switch(globalDifficulty){
        case 1:
        eSpeed = 3;
        break;

        case 2:
        eSpeed = 4;
        break;

        case 3:
        eSpeed = 6;

        break;

        case 4:
        eSpeed = 8;
        break;

        case 5:
        eSpeed = 10;
        break;

        default:

        eSpeed = 3;
        break;
      }
        Assign(place1);
        Assign(place2);
        Assign(place3);
        Assign(place4);
        Assign(place5);
        Assign(place6);
        blitzTime = 12f;


    if(!isBlitzMode){
      } else {
        GameObject scoretext = GameObject.Find("Score");
      scoretext.SetActive(false);
      }

      }



    

    // Update is called once per frame
    void Update()
    {
        timescale += Time.deltaTime;


        if(timescale >= 0.1f && !RaceFinish && gamestart){
            timescale = 0f;
            score +=0.1f;
            string scoreStr = score.ToString();
            if(scoreStr.Length > 3 && score < 10f){
                string num = scoreStr[0].ToString() + scoreStr[1].ToString() + scoreStr[2].ToString();
                score = float.Parse(num);
            } else if(scoreStr.Length > 3 && score > 10f){
                string num = scoreStr[0].ToString() + scoreStr[1].ToString() + scoreStr[2].ToString() + scoreStr[3].ToString();
                score = float.Parse(num);
            }


        }

        if(Time.time < 1){
            StartText.text = "3";
        } else if(Time.time > 1 && Time.time < 2){
            StartText.text = "2";
        } else if(Time.time > 2 && Time.time < 3){
            StartText.text = "1";
        } else if(Time.time > 3 && Time.time < 3.5){
            StartText.text = "GO!";
        }  else {
            StartCanvas.GetComponent<Canvas>().enabled = false;
            gamestart = true;
        } 


        if(RaceFinish == true && !isBlitzMode){
            endingMenu.GetComponent<Canvas>().enabled = true; 
            endingPanel.GetComponent<Canvas>().enabled = true;

            if(score < GlobalMenuManager.tpRaceTime || GlobalMenuManager.tpRaceTime == 0){
                string scoreStr = score.ToString();
                if(scoreStr.Length > 3 && score < 10f){
                    string num = scoreStr[0].ToString() + scoreStr[1].ToString() + scoreStr[2].ToString();
                    score = float.Parse(num);
                    Debug.Log(score);
                } else if(scoreStr.Length > 3 && score > 10f){
                    string num = scoreStr[0].ToString() + scoreStr[1].ToString() + scoreStr[2].ToString() + scoreStr[3].ToString();
                    score = float.Parse(num);
                    Debug.Log(score);
                }
                GlobalMenuManager.tpRaceTime = score;
                 highscore.text = "Fastest Time: " + score;
                 Debug.Log(score);
            } else {
            highscore.text = "Fastest Time: " + GlobalMenuManager.tpRaceTime;
            }
        } else if(RaceFinish && isBlitzMode){
            if(PlayerLost){
                SceneManager.LoadScene("BlitzModeEnd");
            } else if(!(Blitzmode.GamesPlayed % 6 == 0) && !PlayerLost){
                Blitzmode.playInterlude();
                PlayerPrefs.SetInt("BlitzScore", PlayerPrefs.GetInt("BlitzScore") + 1);
            } else {
                Blitzmode.playLevelScreen();
            }
        } 

        curScore.text = "Time: " + score;
    }

    public void reloadScreen() {
        SceneManager.LoadScene("tpRace");

    }


    public void submitRaceTime() {
        User user = new User();
        if(GlobalMenuManager.localId == null){
            Debug.Log("no user selected");
        } else {

      
        RestClient.Put("https://comp-2800-bby-35.firebaseio.com/UsersId/" + GlobalMenuManager.localId + ".json", user).Catch(error =>{
            Debug.Log("error");
        });
      }



    }


    public void Assign(GameObject g){
        int x = Random.Range(0, 2);

        if(x == 1){
           Instantiate(sign, new Vector3(g.transform.position.x, g.transform.position.y,-0.10f), Quaternion.identity);
        } else {
            Instantiate(puddle, new Vector3(g.transform.position.x, g.transform.position.y, -0.10f), Quaternion.identity);
        }

    }
    
}
