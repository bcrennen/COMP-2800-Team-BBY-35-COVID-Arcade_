﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tpracemainrun : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       Rigidbody2D rb = gameObject.GetComponent<Rigidbody2D>();

        rb.velocity = new Vector2(3f, 0f);
        if(transform.position.x > 10){
            transform.position = new Vector2(-10f, transform.position.y);
        }
    }
}
