﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerRunnerTP : MonoBehaviour
{
    Rigidbody2D rb;
    public Button left;
    float xSpeed= 0;

    float ySpeed = 0;

    public bool isMoving;


    private bool gLeft = true;

    private bool gRight = true;

    public bool isSliding = false;

    public bool isJumping = false;

    public bool isGrounded = true;

    public float slidingTimer;

    public float movingTimer;
    public Button right;

    public Sprite SlideSprite;

    public Sprite knockOver;
    public float stepsTaken = 0;

   public Sprite jumpSprite;
    public Sprite regSprite;

    GameObject gM;
      TPGameLogic gL;
    void Start()
    {
    gM = GameObject.Find("GameMaster");
    gL = gM.GetComponent<TPGameLogic>();
    rb = gameObject.GetComponent<Rigidbody2D>();
    movingTimer = 0.5f;
    slidingTimer = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        if(TPGameLogic.gamestart){

        if(slidingTimer > 0){
            slidingTimer -= Time.deltaTime;
            refreshMovingTimer();
        }
        if(slidingTimer <= 0){
            isSliding = false;
            isJumping = false;
            ySpeed = -10f;
            gameObject.GetComponent<Animator>().enabled = true;
        }

        if(movingTimer > 0){
        movingTimer -= Time.deltaTime;
        } 
        if(movingTimer <= 0){
            isMoving = false;
        }
        if(xSpeed < 0){
            xSpeed = 0;
        }

        if(isJumping){
         ySpeed = 5f;
        }

        if(rb.velocity.x >= 0 && isMoving == false && xSpeed > 0){
            xSpeed -= 0.4f;
        }

        rb.velocity = new Vector3(xSpeed, ySpeed, 0f);

        if(Input.GetKeyDown(KeyCode.A) && gLeft == true){
            MoveLeft();
            gLeft = false;
            gRight = true;
        }

        if(Input.GetKeyDown(KeyCode.D) && gRight == true){
            MoveLeft();
            gLeft = true;
            gRight = false;
        } 

        if(Input.GetKeyDown(KeyCode.S) && !isSliding && !isJumping){
            Slide();
        } 

        if(Input.GetKeyDown(KeyCode.W) && !isJumping && isGrounded){
            Jump();
        } 
        }
    }



    public void MoveLeft(){
        if(TPGameLogic.gamestart && !isSliding && !isJumping){
        if(xSpeed < 10){
        xSpeed += 2f;
        stepsTaken++;
        } else if(xSpeed >= 10) {
        xSpeed += 0.3f;
        }

        refreshMovingTimer();
        }
    }

    public void Slide(){
  if(TPGameLogic.gamestart){
        isSliding = true;
             refreshSlidingTimer();
             gameObject.GetComponent<Animator>().enabled = false;
             gameObject.GetComponent<SpriteRenderer>().sprite = SlideSprite;
  }
    }


        public void Jump(){
  if(TPGameLogic.gamestart && isGrounded){
        isJumping = true;
             refreshSlidingTimer();
            gameObject.GetComponent<Animator>().enabled = false;
             gameObject.GetComponent<SpriteRenderer>().sprite = jumpSprite;
  }
    }

    public void refreshMovingTimer(){
        movingTimer  = 0.5f;
        isMoving = true;

    }

    public void refreshSlidingTimer(){
        slidingTimer  = 0.5f;

    }


    private void OnTriggerEnter2D(Collider2D other){

        if(other.tag == "FinishLine"){
             rb.velocity = new Vector3(0f, 0f, 0f);
            gL.RaceFinish = true;
            Debug.Log("Enter");
        
        }

        if(other.tag == "ground"){
            isGrounded = true;
        }


        if(other.tag == "puddle" && isSliding == false){
            Debug.Log("enter and slow");
            xSpeed -= xSpeed/2;
        } else if(other.tag == "puddle" && isSliding) {
            other.GetComponent<SpriteRenderer>().sprite = knockOver;

        }


        if(other.tag == "Jumpover" && isJumping == false){
            Debug.Log("enter and slow");
            xSpeed -= xSpeed/2;
        }

    }


    private void OnTriggerExit2D(Collider2D other){
        if(other.tag == "ground"){
            isGrounded = false;
        }

    }
}
