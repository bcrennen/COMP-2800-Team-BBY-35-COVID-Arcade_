﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyRunner : MonoBehaviour

{

    Rigidbody2D rb;

    GameObject player;


    public float EnemySpeed;
    // Start is called before the first frame update
    void Start()
    {
     rb = gameObject.GetComponent<Rigidbody2D>();   
    player = GameObject.Find("playertprace");
     EnemySpeed = TPGameLogic.eSpeed;
    }

    // Update is called once per frame
    void Update()
    {   
        if(TPGameLogic.gamestart){
        rb.velocity = new Vector3(EnemySpeed, 0f, 0f);
        }

    }


    public void OnTriggerEnter2D(Collider2D other){
        if(other.tag == "FinishLine"){
            TPGameLogic.PlayerLost = true;

        }

    }
}
