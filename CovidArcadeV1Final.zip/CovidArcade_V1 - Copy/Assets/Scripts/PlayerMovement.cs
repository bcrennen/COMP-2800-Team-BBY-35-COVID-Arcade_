﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
  private Rigidbody2D rb;
  public BoxCollider2D left;
  public BoxCollider2D Right;
  public ScreenShake camShake;
  public AudioSource bump;
  public float moveSpeed = 1;
  private bool isMoving = false;
    // Start is called before the first frame update
    void Start()
    {
            rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
      if(isMoving == false){
      if(Input.GetMouseButtonDown(0)){
        Vector3 mPos = Input.mousePosition;
        mPos = Camera.main.ScreenToWorldPoint(mPos);

        if(mPos.x <= -2.44f && transform.position.x != -2.64f){
          rb.velocity = new Vector3(-moveSpeed, 0f, 0f);
          isMoving = true;


        } else if(mPos.x >= 1.44f && transform.position.x < 1.56f){
          rb.velocity = new Vector3(moveSpeed, 0f, 0f);
          isMoving = true;
        }



      }

      }
    }

       void OnTriggerEnter2D(Collider2D other){

         Debug.Log("enter");
         if(other.tag == "stop"){
          rb.velocity = new Vector3(0f, 0f, 0f);
          StartCoroutine(camShake.shake(0.10f, .1f));
          bump.Play();
          isMoving = false;
          

        } else if(other.tag == "Enemy" || other.tag == "Car"){
           StartCoroutine(camShake.shake(0.10f, .1f));
          Destroy(gameObject);
        }
       }

}
