﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Greeting : MonoBehaviour
{
    public TextMeshProUGUI GreetingText;
    void Start()
    {
        GreetingText.text = "Welcome " + GlobalMenuManager.playerName + "! Please Select a Game type."; 
    }

    // Update is called once per frame
    void Update()
    {
        
    }



    
}
