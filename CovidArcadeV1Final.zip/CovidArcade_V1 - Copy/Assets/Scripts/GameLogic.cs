﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Proyecto26;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
public class GameLogic : MonoBehaviour
{
    public static float globalDifficulty;
    private float cap;

    public float blitzTime = 10f;

    public static bool isBlitzMode;

    public TextMeshProUGUI blitztimeText;
    public float diff;
    public float tim;
    public float displaytim;
    private float score = 0;
    public TextMeshProUGUI display;
    public TextMeshProUGUI displayHighscore;
    public GameObject CanvasObject;
    public GameObject CanvasObjectpanel;
    public InputField nameinput;
    private User main;
    public GameObject Player;

    void Start()
    {
      if(isBlitzMode){
        globalDifficulty = Blitzmode.diff;
      
        GameObject.Find("joggerSong").GetComponent<AudioSource>().enabled = false;
      } else {
      globalDifficulty = MainMenu.Difficulty;
      }
      switch(globalDifficulty){
        case 1:
        diff = 1f;
        cap = 4f;
        break;

        case 2:
        diff = 1.5f;
        cap = 4f;
        break;

        case 3:
        diff= 2f;
        cap = 4f;
        break;

        case 4:
        diff= 3f;
        cap = 4f;
        break;

        case 5:
        diff= 4f;
        cap = 4f;
        break;

        default:
        diff = 1f;
        cap = 5f;
        break;
      }
      blitzTime = 12f;
      tim = 0f;
      displaytim = 0f;
      if(!isBlitzMode){
      display.text = "Score: " + score;
      GameObject blitztext = GameObject.Find("BlitzTimerCanvas");
      blitztext.GetComponent<Canvas>().enabled = false;
      }
      displayHighscore.text = "HighScore: " + GlobalMenuManager.joggerScore;

      
    }

    // Update is called once per frame
    void Update()
    {
      if(isBlitzMode){
        blitzTime -= Time.deltaTime;
        string bTime = blitzTime.ToString();
        if(blitzTime < 10){
        blitztimeText.text = "Time Left: " + bTime[0]; 
        } else {
          blitztimeText.text = "Time Left: " + bTime[0] + bTime[1]; 
        }

      }

      if(blitzTime <= 0 && Player != null){
        PlayerPrefs.SetInt("SampleScene", 1);
        PlayerPrefs.SetInt("BlitzScore", PlayerPrefs.GetInt("BlitzScore") + 1);
        if(!(Blitzmode.GamesPlayed % 6 == 0)){
        Blitzmode.playInterlude();
        } else {
        Blitzmode.playLevelScreen();
        }
      }

        tim += Time.deltaTime;
        displaytim += Time.deltaTime;
        if (tim >= 3f){
          if(diff < cap){
          diff += 0.2f;
          tim = 0f;
          }
        }

        if(displaytim >= 1f && Player != null && !isBlitzMode){
          score++;
          display.text = "Score: " + score;
          displaytim = 0f;
        }

        if(Player == null && isBlitzMode == false){
          CanvasObject.GetComponent<Canvas> ().enabled = true;
          CanvasObjectpanel.GetComponent<Canvas> ().enabled = true;
          if(GlobalMenuManager.joggerScore < score){
          GlobalMenuManager.joggerScore = score;
           displayHighscore.text = "HighScore: " + score;
          
          }
          } else if(Player == null && isBlitzMode) {
              SceneManager.LoadScene("BlitzModeEnd");
          } 


        }


    

    public void tryAgain() {
      SceneManager.LoadScene(2);

    }

    public void quit() {
      SceneManager.LoadScene(1);

    }

    public void onSubmit(){
     
           PostToDatabase();
       
       
      
    }


    void PostToDatabase() {

      User user = new User();
      if(GlobalMenuManager.localId == null){
        Debug.Log("no user selected");
      } else {

      
      RestClient.Put("https://comp-2800-bby-35.firebaseio.com/UsersId/" + GlobalMenuManager.localId + ".json", user).Catch(error =>{
        Debug.Log("error");
      });
      }

    }

    public void RetrieveFromDatabase() {
      RestClient.Get<User>("https://comp-2800-bby-35.firebaseio.com/" + nameinput.text + ".json").Then(response =>{
       main = response;   
      });
    }

}

