﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public bool gameOver = false;
    public float speed = 5f;
    public float min_y, max_y; 
    private float mouseposX;
    public static bool isBlitzMode;

    public float blitzTime = 7f;

    private float playposY;
    public Canvas endScreen;

    [SerializeField]
    private GameObject playerBullet;

    [SerializeField]
    private Transform soapSpawn;

    public float attk_Timer = 1f;
    private float current_attk_time;
    private bool canAttk;
    private AudioSource explosionSound;

    private void Awake()
    {
        explosionSound = GetComponent<AudioSource>();
    }

    // Start is called before the first frame update
    void Start()
    {
        blitzTime = 10f;
        endScreen.GetComponent<Canvas>().enabled = false;
        current_attk_time = attk_Timer;
    }

    // Update is called once per frame
    void Update()
    {
    if(isBlitzMode){
        blitzTime -= Time.deltaTime;
      }

      if(blitzTime <= 0 && gameObject != null){
        PlayerPrefs.SetInt("HandWash", 1);
        PlayerPrefs.SetInt("BlitzScore", PlayerPrefs.GetInt("BlitzScore") + 1);
        if(!(Blitzmode.GamesPlayed % 6 == 0)){
        Blitzmode.playInterlude();
        } else {
        Blitzmode.playLevelScreen();
        }
      }

        MovePlayer();
    }

    void MovePlayer()
    {
        if (Input.GetKey(KeyCode.W))
        {
            Vector3 temp = transform.position;
            temp.y += speed * Time.deltaTime;

            if (temp.y > max_y)
                temp.y = max_y;

            transform.position = temp;
        }

        if (Input.GetKey(KeyCode.S))
        {
            Vector3 temp = transform.position;
            temp.y -= speed * Time.deltaTime;

            if (temp.y < min_y)
                temp.y = min_y;

            transform.position = temp;
        }

    }

    public void MovePlayerUp()
    {
        Vector3 temp = transform.position;
        temp.y += speed * Time.deltaTime;

        if (temp.y > max_y)
            temp.y = max_y;

        transform.position = temp;
    }

    public void MovePlayerDown()
    {
            Vector3 temp = transform.position;
            temp.y -= speed * Time.deltaTime;

            if (temp.y < min_y)
                temp.y = min_y;

            transform.position = temp;
    }
    /*{
        if (Input.GetAxisRaw("Vertical") > 0f)
        {
            Vector3 temp = transform.position;
            temp.y += speed * Time.deltaTime;

            if (temp.y > max_y)
                temp.y = max_y;

            transform.position = temp;
        }
        else if (Input.GetAxisRaw("Vertical") < 0f)
        {
            Vector3 temp = transform.position;
            temp.y -= speed * Time.deltaTime;

            if (temp.y < min_y)
                temp.y = min_y;

            transform.position = temp;
        }
    }*/

    public void Shoot()
    {
        attk_Timer += Time.deltaTime;
        if (attk_Timer > current_attk_time)
        {
            canAttk = true;
        }

            if (canAttk)
            {
                canAttk = false;
                attk_Timer = 0f;

                Instantiate(playerBullet, soapSpawn.position, Quaternion.identity);

                //play sound FX
            }
    }

    void TurnOffGameObject()
    {
        gameObject.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D target)
    {
        if (target.tag == "Bullet" || target.tag == "Enemy")
        {
             if(isBlitzMode){
                SceneManager.LoadScene("BlitzModeEnd");
            }
            endScreen.GetComponent<Canvas>().enabled = true;
            Debug.Log("GAME OVER");
            explosionSound.Play();
            Invoke("TurnOffGameObject", 0.25f);
            Destroy(gameObject);
        }
    }


    public void EndGame(){
            if(isBlitzMode){
                SceneManager.LoadScene("BlitzModeEnd");
            }
            endScreen.GetComponent<Canvas>().enabled = true;
            Debug.Log("GAME OVER");
            explosionSound.Play();
            Invoke("TurnOffGameObject", 0.25f);
            Destroy(gameObject);
    }
}
