﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawnerScript : MonoBehaviour { 

    public GameObject enemy;
    float randX;
    float randY;

    public static bool isBlitzMode;
    Vector2 whereToSpawn;
    public float spawnrate = 2f;
    float nextSpawn = 0.0f;

    public float dif;

 public bool dogMode;



    // Start is called before the first frame update
    void Start()
    {
        if(isBlitzMode){
            dif = Blitzmode.diff;
        } else {
            dif = MainMenu.Difficulty;
        }
        switch(dif){
            case 1:
                spawnrate = 2f;
            break;

            case 2:
            spawnrate = 1.5f;
            break;
            
            case 3:
            spawnrate = 1.25f;
            break;

            case 4:
            spawnrate = 1f;
            break;

            case 5:
            spawnrate = 0.75f;
            break;

        default:
            spawnrate = 2f;
        break;
      }
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnrate;
            randY = Random.Range(-4, 4f);
            whereToSpawn = new Vector2(12, randY);
            Instantiate(enemy, whereToSpawn, Quaternion.identity);
            

        }

    }



}
