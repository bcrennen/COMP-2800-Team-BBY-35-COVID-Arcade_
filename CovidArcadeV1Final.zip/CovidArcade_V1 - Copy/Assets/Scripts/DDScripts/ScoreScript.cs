﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Proyecto26;
using TMPro;
public class ScoreScript : MonoBehaviour
{
    float score = 0;
    public Canvas EndingScreen;

    public Text highScore;
    public TextMeshProUGUI blitztimeText;

    public float blitzTime;

    public Text currentScore;

    private void Start()
    {
        highScore.text = "Highscore: " + GlobalMenuManager.dogfightScore;
        blitzTime = 12f;
        
    if(!PlayerController.isBlitzMode){
      GameObject blitztext = GameObject.Find("BlitzTimerCanvas");
      blitztext.GetComponent<Canvas>().enabled = false;
      }
    }

    private void Update()
    {
      if(PlayerController.isBlitzMode){
        blitzTime -= Time.deltaTime;
        string bTime = blitzTime.ToString();
        if(blitzTime < 10){
        blitztimeText.text = "Time Left: " + bTime[0]; 
        } else {
          blitztimeText.text = "Time Left: " + bTime[0] + bTime[1]; 
        }

      }

        if(!PlayerController.isBlitzMode){
        score = (10 * EnemyScript.score);
        currentScore.text = "Score: " + score;
        }

        if (score > GlobalMenuManager.dogfightScore)
        {
            GlobalMenuManager.dogfightScore = score;
            highScore.text = "Highscore: " + GlobalMenuManager.dogfightScore;
        }
    }


        public void submitRaceTime() {
        if(score > GlobalMenuManager.dogfightScore){
        GlobalMenuManager.dogfightScore = score;
        }
        User user = new User();
        if(GlobalMenuManager.localId == null){
            Debug.Log("no user selected");
        } else {
        RestClient.Put("https://comp-2800-bby-35.firebaseio.com/UsersId/" + GlobalMenuManager.localId + ".json", user).Catch(error =>{
            Debug.Log("error");
        });
      }



    }
}
