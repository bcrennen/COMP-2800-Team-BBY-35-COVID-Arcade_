﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Blitzmode : MonoBehaviour
{

    public static string[] gameTitles = new string[5];
    public static int curGame = 0;

    public static int GamesPlayed = 0;

    public static int diff = 0;
    // Start is called before the first frame update
    void Start()
    {

        diff = 1;
        gameTitles[0] = "SampleScene";
        gameTitles[1] = "HandWash";
        gameTitles[2] = "tpRace";
        gameTitles[3] = "DontTouchFace";
        gameTitles[4] = "CoughCatcher";

        PlayerPrefs.SetInt(gameTitles[0], 0);
        PlayerPrefs.SetInt(gameTitles[1], 0);
        PlayerPrefs.SetInt(gameTitles[2], 0);
        PlayerPrefs.SetInt(gameTitles[3], 0);
        PlayerPrefs.SetInt(gameTitles[4], 0);
        PlayerPrefs.SetInt("BlitzScore", 0);

        PlayerController.isBlitzMode = true;
        GameLogic.isBlitzMode = true;
        FaceScript.isBlitzMode = true;
        TPGameLogic.isBlitzMode = true;
        EnemySpawnerScript.isBlitzMode = true;
        HandSpawnerScript.isBlitzMode = true;
        CCGameLogic.isBlitzMode = true;

        Shuffle(gameTitles);
        curGame = 0;
        GamesPlayed = 0;
        diff = 1;

        playGame();
        
    }

    // Update is called once per frame
    void Update()
    {
        foreach(string s in gameTitles){
            if(PlayerPrefs.GetInt(s) == 2){
                gameOver();
            }
        }
        
    }



    public static void playGame() {
        if(!(GamesPlayed % 6 == 0)){
        GamesPlayed++;
        Debug.Log("fadsdds");
        SceneManager.LoadScene(gameTitles[curGame]);
        curGame++;
        if(curGame == 5){
            curGame = 0;
            if(diff < 5){
                diff++;
            }
        }
        } else {
            SceneManager.LoadScene("LevelScreen");
           
        }

    }


    public void gameOver(){
        Debug.Log("GameOver");
        
    }

    public static void playInterlude(){
        SceneManager.LoadScene("Interlude");

    }
    
    public static void playLevelScreen(){
        SceneManager.LoadScene("LevelScreen");

    }

     public void Shuffle(string[] decklist) 
 {
     List<int> used = new List<int>();
     string tempGO;
          for (int i = 0; i < decklist.Length - 1; i++) 
          {
              
              int rnd = Random.Range(i, decklist.Length);
              tempGO = decklist[rnd];
              decklist[rnd] = decklist[i];
              decklist[i] = tempGO;
          }
 }
}
