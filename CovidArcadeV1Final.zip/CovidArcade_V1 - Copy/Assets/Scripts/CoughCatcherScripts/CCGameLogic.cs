﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using Proyecto26;

public class CCGameLogic : MonoBehaviour
{
    public static int globalDifficulty = 0;
    public static float handSpeed;

      public static bool isBlitzMode = false;
    public float next = 0;
    public int done = 0;
    private float time;
    private float startTime = 1f;
    public static bool isStart = false;
    public float endTime = 7f;
    public bool isEnd = false;

    public TextMeshProUGUI ScoreText;

    public TextMeshProUGUI timer;

    public TextMeshProUGUI displayHighscore;

    public float blitzTime = 12f;

    private static int score;
    public int armsIn = 0;

    public GameObject Hand1;
    public GameObject Hand2;
    public GameObject Hand3;

    public Canvas endGameText;

    public Canvas endGamePanel;
    
    void Start()
    {
      if(!isBlitzMode){
      globalDifficulty++;
      time = 0;
      isStart = false;
      isEnd = false;
      } else if(isBlitzMode){
        globalDifficulty = Blitzmode.diff;
        Debug.Log(Blitzmode.diff + " and " + globalDifficulty);
        ScoreText.enabled = false;
        isStart = false;
        isEnd = false;
      }
      
      switch(Blitzmode.diff){
        case 1:
          startTime = 3f;
          blitzTime = 12f;
        break;

        case 2:
          startTime = 1.5f;
          blitzTime = 10f;
        break;

        case 3:
           startTime = 1.25f;
           blitzTime = 9f;
        break;

        case 4:
          startTime = 1f;
          blitzTime = 8f;
        break;

        case 5:
            startTime = 0.75f;
            blitzTime = 7f;
        break;

        default:
            startTime = 0.75f;
            blitzTime = 7f;
        break;
      }

                startTime = 3f;
          blitzTime = 12f;

    }

    // Update is called once per frame
    void Update()
    {
     
      time += Time.deltaTime;
      if(time >= startTime){
        isStart = true;
        if(!isEnd && !isBlitzMode){
        blitzTime -= Time.deltaTime;
        string bTime = blitzTime.ToString();
        if(blitzTime < 10){
        timer.text = "Time Left: " + bTime[0]; 
        } else {
          timer.text = "Time Left: " + bTime[0] + bTime[1]; 
        }
        if(blitzTime <= 0){

          placementFinished();
        }

        }
      }
      if(!isBlitzMode)
      ScoreText.text = "Score: " + score;

      if(isStart && isBlitzMode){
        blitzTime -= Time.deltaTime;
        string bTime = blitzTime.ToString();
        if(blitzTime < 10){
        timer.text = "Time Left: " + bTime[0]; 
        } else {
          timer.text = "Time Left: " + bTime[0] + bTime[1]; 
        }
        if(blitzTime <= 0){

          placementFinished();
        }
      }

        
      

    }


    public float getNext(){
      return next;
    }

    public void incNext(){
      next++;
    }

        IEnumerator wait(int s){
        Debug.Log("wait Start");
        yield return new WaitForSeconds(s);
          if(!isBlitzMode){
         SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        Debug.Log("wait end");
          } else {
           if(!(Blitzmode.GamesPlayed % 6 == 0)){
         PlayerPrefs.SetInt("BlitzScore", PlayerPrefs.GetInt("BlitzScore") + 1);
        Blitzmode.playInterlude();
        } else {
        Blitzmode.playLevelScreen();
        }
          }
    }

    public void placementFinished() {

        isEnd = true;
        Hand1.GetComponent<BoxCollider2D>().enabled = true;
        Hand2.GetComponent<BoxCollider2D>().enabled = true;
        Hand3.GetComponent<BoxCollider2D>().enabled = true;

        if(armsIn >= 3){
          armsIn = 0;
          score++;
          ScoreText.text = "Score: " + score;
          done = 0;
          next = 0;
          StartCoroutine(wait(2));

          

        } else {

          StartCoroutine(waitLose(2));
        }

    }

    public void tryAgain(){

    SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    globalDifficulty = 0;
    score = 0;

    }

    public void quit(){
      globalDifficulty = 0;
      score = 0;
      SceneManager.LoadScene("CoughCatcherMenu");

    }

    public void PostCCScoreToDatabase() {

      User user = new User();
      if(GlobalMenuManager.localId == null){
        Debug.Log("no user selected");
      } else {
      RestClient.Put("https://comp-2800-bby-35.firebaseio.com/UsersId/" + GlobalMenuManager.localId + ".json", user).Catch(error =>{
        Debug.Log("error");
      });
      }

    }

     IEnumerator waitLose(int s){
        Debug.Log("wait Start");
        yield return new WaitForSeconds(s);
        if(!isBlitzMode){
         endGamePanel.GetComponent<Canvas>().enabled = true;
           endGameText.GetComponent<Canvas>().enabled = true;
          if(GlobalMenuManager.joggerScore < score){
          GlobalMenuManager.coughcatcherScore = score;
           displayHighscore.text = "HighScore: " + score;
          
          } else {
            displayHighscore.text = "HighScore: " + GlobalMenuManager.coughcatcherScore;
          }


        
        Debug.Log("wait end");
    } else {
      SceneManager.LoadScene("BlitzModeEnd");
     }

}
}
