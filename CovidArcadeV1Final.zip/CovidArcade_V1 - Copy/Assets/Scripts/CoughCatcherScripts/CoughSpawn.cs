﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoughSpawn : MonoBehaviour
{
    GameObject gM;
    CCGameLogic gL;
    private float off = 0;
    void Start()
    {
      float y = Random.Range(-6.77f, -0.7f);

      transform.position = new Vector3(transform.position.x, y, 0f);
       gM = GameObject.Find("GameMaster");
       gL = gM.GetComponent<CCGameLogic>();


    }

    // Update is called once per frame
    void Update()
    {
      if(CCGameLogic.isStart == true && off == 0f){
        GetComponent<Renderer>().enabled = !GetComponent<Renderer>().enabled;
        off = 1f;
      }

      if(gL.isEnd == true && off == 1f){

        GetComponent<Renderer>().enabled = !GetComponent<Renderer>().enabled;
        off++;
      }
    }

    void OnTriggerEnter2D(Collider2D other){
      gL.armsIn++;


    }


    void OnTriggerExit2D(Collider2D other){
      gL.armsIn--;


    }
   
}
