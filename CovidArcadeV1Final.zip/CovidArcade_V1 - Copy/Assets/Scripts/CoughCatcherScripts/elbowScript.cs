﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class elbowScript : MonoBehaviour
{

  private float StartX;

  private float StartY;

  public bool IsHeld = false;
  private Rigidbody2D rb;
  public bool isMoving = false;
  private GameObject gM;
  private CCGameLogic gL;
    // Start is called before the first frame update
    void Start()
    {
      gM = GameObject.Find("GameMaster");
      gL = gM.GetComponent<CCGameLogic>();
      rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {


     if(IsHeld == true){
        Vector3 mousPos;
        mousPos = Input.mousePosition;
      mousPos = Camera.main.ScreenToWorldPoint(mousPos);
       this.gameObject.transform.localPosition = new Vector3(mousPos.x, mousPos.y, -1f);

     }
  }

  private void OnMouseDown(){
    if(Input.GetMouseButtonDown(0) && CCGameLogic.isStart){
     IsHeld = true;
    }
  }

  private void OnMouseUp(){
    IsHeld = false;
  }

}
