﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JoggerEnemycript : MonoBehaviour
{
    public float interval;

    public float Spawntime;

    public float x;

    public GameObject Enemy;
    void Start()
    {
        switch(Blitzmode.diff){
        case 1:
           Spawntime = 2f;
        break;

        case 2:
            Spawntime = 1.5f;
        break;

        case 3:
            Spawntime = 1.25f;
        break;

        case 4:
            Spawntime = 0.7f;
        break;

        case 5:
            Spawntime = 0.5f;
        break;

        default:
            Spawntime = 2f;
        break;
      }


    }

    // Update is called once per frame
    void Update()
    {
        interval += Time.deltaTime;

        if(interval >= Spawntime){
            x = Random.Range(0f, 2f);
            if(x <= 1){
                Instantiate(Enemy, new Vector3(-2.44f, 10f, -2f), Quaternion.identity);

            } else if(x <= 2 && x > 1){
                Instantiate(Enemy, new Vector3(1.51f, 10f, -2f), Quaternion.identity);
            }

            if(Spawntime >= 0.7f && Time.time > 10){
                Spawntime -= 0.1f;
            }
            interval = 0;
        }
        
    }
}
