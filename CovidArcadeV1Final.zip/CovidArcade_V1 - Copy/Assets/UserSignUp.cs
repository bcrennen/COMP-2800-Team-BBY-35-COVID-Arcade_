﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class UserSignUp
{

    public string email;
    public string password;

    public bool returnSecureToken = true;
    
}
