﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStop : MonoBehaviour
{

    public GameObject player;
    // Start is called before the first frame update
    void OnTriggerEnter2D(Collider2D other){
        Debug.Log("entered");
        if(other.tag == "player"){
            player.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 0f, 0f);


        }
    }
}
