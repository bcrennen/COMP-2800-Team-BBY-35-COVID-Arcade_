﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{

    public static int Difficulty;
    public InputField dif;

    public void playGame() {
        SceneManager.LoadScene(2);


    }

    public void playCoughCatcher() {
        SceneManager.LoadScene(5);


    }

    public void Apply() {
         Difficulty = int.Parse(dif.text);
    }


    public void instructions() {


        
    }
}
