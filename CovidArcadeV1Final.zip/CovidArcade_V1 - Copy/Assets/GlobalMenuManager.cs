﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Proyecto26;
using TMPro;

public class GlobalMenuManager : MonoBehaviour
{   
    //the user that is currently logged in
    private User main;

    // these two variables hold the entered user inputs
    public InputField emailText;
    public InputField passwordText;


    public static float joggerScore;
    public static float coughcatcherScore;
    public static float dogfightScore;

    public static float blitzmodeScore;

    public static float tpRaceTime;

    public static float tfScore;

    public static float playerScore;
    public static string playerName;

    //id token and localid for user.
    public static string idToken;
    public static string localId;

    //firebase authentication key
    public string AuthKey = "AIzaSyCmuxXOQm5Bjl9THSj50_3TCHWLC3_w_Yk";


    public void mainMenuBack(){
        SceneManager.LoadScene("GlobalMainMenu");

    }

    public void tpRaceMain() {
        SceneManager.LoadScene("tPMain");
        
    }

    public void creditsPage(){
        SceneManager.LoadScene("Credits");

    }

    public void SignInPage() {
        SceneManager.LoadScene("SignIn");


    }

    public void blitzmodeStart(){
        SceneManager.LoadScene("BlitzMode");

    }

    public void blitzmenu(){
        SceneManager.LoadScene("BlitzMenu");

    }

    public void GameLibrary(){
        SceneManager.LoadScene("GameLibrary");
        
    }

    public void TFMenu() {
        SceneManager.LoadScene("TFMenu");

    }
        public void ChooseMenu() {
        SceneManager.LoadScene("ChooseMode");

    }

    public void RunnerMenu() {
        SceneManager.LoadScene("Menu");
    }

    public void DogFightMenu() {
        SceneManager.LoadScene(12);
    }

    public void TPrace(){
        SceneManager.LoadScene("tpRace");
    }

    public void CoughCatcherMenu() {
        SceneManager.LoadScene(6);
    }

    public void OpenWebsite(){
        Application.OpenURL("https://slim01.blob.core.windows.net/project2800/index.html");
          Debug.Log("is this working?");
    }

    // public void Login(){
    //     StartCoroutine(wait(1));
        

    // }

    void PostToDatabase() {

      User user = new User();
      RestClient.Put("https://comp-2800-bby-35.firebaseio.com/UsersId/" + localId + ".json", user);


    }


    public void signinButtonPush() {
         Debug.Log("1");
         StartCoroutine(wait(1));
    }

    
    public void signUpButtonPush() {
         Debug.Log("1");
        SignUp(emailText.text, playerName, passwordText.text);
    }


    public void RetrieveFromDatabase() {
        RestClient.Get<User>("https://comp-2800-bby-35.firebaseio.com/" + emailText.text + ".json").Then(response =>{
            main = response;   
        });
    }

    IEnumerator wait(int s){
        Debug.Log("wait Start");
        SignIn(emailText.text, passwordText.text);
        yield return new WaitForSeconds(s);

        if(localId == "didntWork"){
           GameObject gM = GameObject.Find("CanvasError");
           gM.GetComponent<Canvas>().enabled = true;
        } else{
            
            SceneManager.LoadScene("ChooseMode");
        }
        Debug.Log("wait end");
    }

    //    private void SignUp(string userEmail, string userPassword){
    //     Debug.Log("1");
    //     string userData = "{\"email\":\"" + userEmail + "\",\"password\":\"" + userPassword + "\",\"returnSecureToken\":true}";
    //    Debug.Log("somethingdif");
    //     RestClient.Post<SignResponse>("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + AuthKey, userData).Then(response =>{
    //         localId = response.localId;
    //         idToken = response.idToken;
    //         PostToDatabase();
    //         Debug.Log("3");
    //     }).Catch(error => {
    //     Debug.Log("error");
    //     Debug.Log(localId);
    //     Debug.Log(userData);
    //     }); 
    //    }

        private void SignUp(string userEmail, string username, string userPassword)
    {
        UserSignUp test = new UserSignUp();
        test.email = userEmail;
        test.password = userPassword;
        string userData = JsonUtility.ToJson(test);
        Debug.Log(userData);
        RestClient.Post<SignResponse>("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + AuthKey, userData).Then(
            response =>
            {
                idToken = response.idToken;
                localId = response.localId;
                playerName = userEmail;
                Debug.Log("it got here atleast");
                PostToDatabase();
                
            }).Catch(error =>
        {
            Debug.Log(error);
        });


    }





    

    private void SignIn(string userEmail, string userPassword){
        UserSignUp test = new UserSignUp();
        test.email = userEmail;
        test.password = userPassword;
        string userData = JsonUtility.ToJson(test);
        RestClient.Post<SignResponse>("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + AuthKey, userData).Then(response =>{
            localId = response.localId;
            idToken = response.idToken;
            GetUserInfo();

         Debug.Log("3");
        }).Catch(error => {

            localId = "didntWork";
        }); 



    }

    private void GetUserInfo() {
        UserParse testParse = new UserParse();
        RestClient.Get<User>("https://comp-2800-bby-35.firebaseio.com/UsersId/" + localId + ".json").Then(response =>{
           playerName = response.userName;
           joggerScore = response.joggerScore;
           coughcatcherScore = response.coughcatcherScore;
           dogfightScore = response.dogfightScore;
           tpRaceTime = response.tpRaceTime;
           blitzmodeScore = response.blitzmodeScore;
           tfScore = response.tfScore;

        });


    
    }



}
