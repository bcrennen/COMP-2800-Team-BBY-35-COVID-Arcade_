﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class User
{
    public string userName;
    public float userScore;
    public string localId;

    public float joggerScore;

    public float tpRaceTime;
    public float tfScore;

    public float dogfightScore;

    public float coughcatcherScore;

    public float blitzmodeScore;
    
    public User()
    {
        userName = GlobalMenuManager.playerName;
        userScore = GlobalMenuManager.playerScore;
        localId = GlobalMenuManager.localId;
        joggerScore = GlobalMenuManager.joggerScore;
        coughcatcherScore = GlobalMenuManager.coughcatcherScore;
        dogfightScore = GlobalMenuManager.dogfightScore;
        blitzmodeScore = GlobalMenuManager.blitzmodeScore;
        tpRaceTime = GlobalMenuManager.tpRaceTime;
        tfScore = GlobalMenuManager.tfScore;

    }
}
