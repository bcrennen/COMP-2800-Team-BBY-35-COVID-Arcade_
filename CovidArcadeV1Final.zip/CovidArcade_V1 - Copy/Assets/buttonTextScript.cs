﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
 using UnityEngine.EventSystems;

public class buttonTextScript : MonoBehaviour
{
    public TextMeshProUGUI desc;
    void Start()
    {
        desc.GetComponent<TextMeshProUGUI>().enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

          public void OnPointerEnter(PointerEventData eventData)
      {
         desc.GetComponent<TextMeshProUGUI>().enabled = true;
      }

            public void OnPointerExit(PointerEventData eventData)
      {
          desc.GetComponent<TextMeshProUGUI>().enabled = false;
      }
}
