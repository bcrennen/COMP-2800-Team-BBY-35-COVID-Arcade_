﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Proyecto26;
using UnityEngine.SceneManagement;
public class BlitzmodeEndScript : MonoBehaviour
{
    public TextMeshProUGUI highscore;
    void Start()
    {
    Destroy(GameObject.FindGameObjectWithTag("Music"));
      
        PlayerController.isBlitzMode = false;
        GameLogic.isBlitzMode = false;
        FaceScript.isBlitzMode = false;
        TPGameLogic.isBlitzMode = false;
        EnemySpawnerScript.isBlitzMode = false;
        HandSpawnerScript.isBlitzMode = false;
        CCGameLogic.isBlitzMode = false;
        highscore.text = "Highscore: " + GlobalMenuManager.blitzmodeScore;
    }

    // Update is called once per frame
    void Update()
    {
        if(PlayerPrefs.GetInt("BlitzScore") > GlobalMenuManager.blitzmodeScore){
            GlobalMenuManager.blitzmodeScore = PlayerPrefs.GetInt("BlitzScore");
              highscore.text = "Highscore: " + GlobalMenuManager.blitzmodeScore;

        }
        PlayerPrefs.SetInt("BlitzScore", 0);
        // if(GameObject.FindGameObjectWithTag("Music").GetComponent<AudioSource>().isPlaying){
        //   Destroy(GameObject.FindGameObjectWithTag("Music"));
        // }
    }

    public void tryAgain(){

    SceneManager.LoadScene("Blitzmode");
    }

    public void quit(){

      SceneManager.LoadScene("BlitzMenu");

    }

        public void PostToDatabase() {

      User user = new User();
      if(GlobalMenuManager.localId == null){
        Debug.Log("no user selected");
      } else {

      
      RestClient.Put("https://comp-2800-bby-35.firebaseio.com/UsersId/" + GlobalMenuManager.localId + ".json", user).Catch(error =>{
        Debug.Log("error");
      });
      }

    }

}
