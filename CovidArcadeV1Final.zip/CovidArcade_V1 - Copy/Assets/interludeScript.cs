﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class interludeScript : MonoBehaviour
{

    public float timevar = 0;
    public int count = 3;
    public TextMeshProUGUI countDown;

    public TextMeshProUGUI desc;

    public TextMeshProUGUI title;
    void Start()
    {
        countDown.text = "" + 3;

        switch(Blitzmode.gameTitles[Blitzmode.curGame]){
            case "SampleScene": 
            title.text = "The Jogger";
            desc.text = "Dodge back and forth to avoid enemies!";
            break;
            
            case "HandWash": 
            title.text = "Disinfect DogFight";
            desc.text = "Destroy all bacteria and avoid enemy fire!";
            break;

            case "tpRace": 
            title.text = "TP Race";
            desc.text = "Beat your opponent to the Toilet paper!";
            break;


            case "DontTouchFace": 
            title.text = "Dont Touch Your Face";
            desc.text = "Tap the hands before they reach the face!";
            break;

   

            case "CoughCatcher": 
            title.text = "Cough Catcher";
            desc.text = "Place the elbows on the mouths of the people. Watch out though, they disapear!";
            break;


        }
    }

    // Update is called once per frame
    void Update()
    {
        timevar += Time.deltaTime;

        if(timevar >= 1 && count >= 1){
            timevar = 0;
            countDown.text = "" + --count;
        }

        if(count == 0){
            Blitzmode.playGame();

        }
    }
}
